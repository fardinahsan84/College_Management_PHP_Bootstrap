
public class Games1 extends Batsmans{

	public double averageOfODI(Batsmans[] batAvg)
	{
		int sum = 0;
	   for(int count=0; count<batAvg.length; count++)
	   {
		   sum+= batAvg[count].total_ODI;
	   }
	   return sum/(batAvg.length);
	}
	


}
