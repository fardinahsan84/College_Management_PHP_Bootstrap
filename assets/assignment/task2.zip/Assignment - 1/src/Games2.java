
public class Games2  {
	 

	//highestWickets(arr[]:Bowlers):void
	  
	 public void highestWickets(highest[]arr)
	 
	  {
		  double highest = arr[0].total_wickets;
		  int track = 0;
		  
		  for(int count=1; count<arr.length; count++)
		  {
			  if(highest < arr[count].total_wickets)
			  {
				  highest = arr[count].total_wickets;
				  track = count;
			  }
		  }
		  
		  System.out.println("Highest wickets is:"+ arr[track].total_wickets + "Name:" + arr[track].Name + "total_match:" + arr[track].total_match + "Total_ODI:"+ arr[track].total_ODI + "Total_Test:" + arr[track].total_Test + "Total_T20:" + arr[track].total_T20+ "Century:"+ arr[track].Century + "Half_century:" + arr[track].Half_century + "Total_Runs:" + arr[track].total_runs + "Total_Wicktes:" + arr[track].total_wicktes);
	  }
}
