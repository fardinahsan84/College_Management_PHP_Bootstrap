
public class Cricket {

	private int total_ODI, total_TEST,total_T20 ,Century, Half_century, total_runs, total_wickets; 
	
	public Cricket()
	{
		
	}
	
	public Cricket(int total_ODI,int total_TEST,int total_T20 ,int Century,int Half_century, int total_runs,int total_wickets) {
		
		this.total_ODI = total_ODI;
		this.total_TEST = total_TEST;
		this.total_T20 = total_T20;
		this.Century = Century;
		this.Half_century = Half_century;
		this.total_runs = total_runs;
		this.total_wickets = total_wickets;
	}
	
	
	//set / get (total_ODI, total_TEST,total_T20 , Century, Half_century, total_runs, total_wickets)
	
	public void setTotal_Odi(int total_ODI)
	 {
		 this.total_ODI= total_ODI;
	 }
	 
	 public int getTotal_Odi() {
		 
		 return total_ODI;
	 }
	 
	 public void setTotal_Test(int total_TEST)
	 {
		 this.total_TEST= total_TEST;
	 }
	 
	 public int getTotal_Test() {
		 
		 return total_TEST;
	 }
	 
	 public void setTotal_T20(int total_T20)
	 {
		 this.total_T20= total_T20;
	 }
	 
	 public int getTotal_T20() {
		 
		 return total_T20;
	 }
	 
	 public void setCentury(int Century)
	 {
		 this.Century= Century;
	 }
	 
	 public int getCentury() {
		 
		 return Century;
	 }
	 
	 public void setHalf_Century(int Half_century)
	 {
		 this.Half_century= Half_century;
	 }
	 
	 public int getHalf_Century() {
		 
		 return Half_century;
	 }
	  	 
	 public void setTotal_Runs(int total_runs)
	 {
		 this.total_runs= total_runs;
	 }
	 
	 public int getTotal_Runs() {
		 
		 return total_runs;
	 }
	 
	 
	 public void setTotal_Wickets(int total_wickets)
	 {
		 this.total_wickets= total_wickets;
	 }
	 
	 public int getTotal_Wickets() {
		 
		 return total_wickets;
	 }
	 
	 /*public void showDetails() {
		 
		 System.out.println("Total_ODI:"+total_ODI + ", Total_Test:"+total_TEST+ ", Total_T20:" +total_T20+ ", Century:"+Century+ ", Half_Century:"+ Half_century+ ", Total_Runs:"+total_runs+ ", Total_Wickets:"+ total_wickets);
	 }*/
	 
	//toString(){}
	 
	 public String toString () {

	     return total_ODI + "  "  + total_TEST +  "  "  +  total_T20 + "  " + Century + "  " + Half_century + "  " + total_runs + "  " + total_wickets;
	   }
}