public class Batsmans extends Cricket{
	
	private String Name;
	private int total_match;
	
	public Batsmans() {
			
	}
	
	public Batsmans(String Name, int total_match, int total_ODI,int total_TEST,int total_T20 ,int Century,int Half_century, int total_runs,int total_wickets)
	{
		super(total_ODI, total_TEST,total_T20 , Century, Half_century, total_runs, total_wickets);
		
		this.Name = Name;
		this.total_match = total_match;
	}
	
	
	//set / get (name, total ,match)
	
	public void setName(String name)
	 {
		 this.Name= name;
	 }
	 
	 public String getName() {
		 
		 return Name;
	 }
	 public void setTotal_match(int total_match)
	 {
		 this.total_match= total_match;
	 }
	 
	 public int getTotal_Match() {
		 
		 return total_match;
	 }
	 
//	 public void showDetails() {
//
//		 System.out.println("Name:" +Name  + "Total Match:" + total_match);
//	 }
	 
	//toString(){}
	 
	 public String toString(){

	       return "Name:" + Name + " Total Match: " + total_match ;
	   }
}

