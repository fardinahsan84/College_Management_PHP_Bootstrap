import java.util.Scanner;

public class Start {
	
	public static void main (String [] args) {
		
		Batsmans[] batArr = new Batsmans[10];
		Bowlers[] bowArr = new Bowlers[10];
		
		Scanner input = new Scanner(System.in) ;
		
		for(int count=0; count<batArr.length; count++ )
		{
			System.out.println("Enter Batsman" + (count+1) + "Information:");
			
			System.out.println("Name:");
			String name = input.nextLine();
			
			System.out.println("Total match:");
			int total_match = input.nextInt();
			
			System.out.println("Total ODI:");
			int total_ODI = input.nextInt();
			
			System.out.println("Total TEST:");
			int total_TEST = input.nextInt();
			
			System.out.println("Total T20:");
			int total_T20 = input.nextInt();
			
			System.out.println("Century:");
			int Century = input.nextInt();
			
			System.out.println("Half Century:");
			int Half_century = input.nextInt();
			
			System.out.println("Total Runs:");
			int total_runs = input.nextInt();
			
			System.out.println("Wotal Wickets:");
			int total_wickets = input.nextInt();
			
			input.nextLine();
		
			batArr[count] = new Batsmans(name,total_match,total_ODI, total_TEST,total_T20 , Century, Half_century, total_runs, total_wickets);
			
		}
	
		//bowlers input using for loop
		
     
		
		for(int count=0; count<bowArr.length; count++ )
		{
			System.out.println("Enter Bowler" + (count+1) + "Informations:");
			
			System.out.println("Name:");
			String name = input.nextLine();
			
			System.out.println("Total Match:");
			int total_match = input.nextInt();
			
			System.out.println("Total ODI:");
			int total_ODI = input.nextInt();
			
			System.out.println("Total TEST:");
			int total_TEST = input.nextInt();
			
			System.out.println("Total T20:");
			int total_T20 = input.nextInt();
			
			System.out.println("Century:");
			int Century = input.nextInt();
			
			System.out.println("Half Century:");
			int Half_century = input.nextInt();
			
			System.out.println("Total Runs:");
			int total_runs = input.nextInt();
			
			System.out.println("Total Wickets:");
			int total_wickets = input.nextInt();
			
			input.nextLine();
		
			bowArr[count] = new Bowlers(name,total_match,total_ODI, total_TEST,total_T20 , Century, Half_century, total_runs, total_wickets);
			
		}
		
		
		
		//show batsmans info using for loop
		
		Batsmans[] batArr=new Batsmans[10];
		String Name;
		int total_match;
		int total_ODI;
		int total_TEST;
		int total_T20 ;
		int Century;
		int Half_century;
		int total_runs;
		int total_wickets;
		
		Scanner input = new Scanner(System.in) ;
		
		for(int count=0; count<batArr.length; count++ )
		{
			System.out.println("Enter Batsman" + (count+1) + "Information:");
			
			System.out.println("Name:");
			String name = input.nextLine();
			
			System.out.println("Total match:");
			int total_match = input.nextInt();
			
			System.out.println("Total ODI:");
			int total_ODI = input.nextInt();
			
			System.out.println("Total TEST:");
			int total_TEST = input.nextInt();
			
			System.out.println("Total T20:");
			int total_T20 = input.nextInt();
			
			System.out.println("Century:");
			int Century = input.nextInt();
			
			System.out.println("Half Century:");
			int Half_century = input.nextInt();
			
			System.out.println("Total Runs:");
			int total_runs = input.nextInt();
			
			System.out.println("Wotal Wickets:");
			int total_wickets = input.nextInt();
			
			input.nextLine();
		
			batArr[count] = new Batsmans(name,total_match,total_ODI, total_TEST,total_T20 , Century, Half_century, total_runs, total_wickets);
			
		}
		
		
		//show bowlers info using for lop
		
		Bowlers[] bowArr=new Bowlers[10];
		String Name;
		int total_match;
		int total_ODI;
		int total_TEST;
		int total_T20 ;
		int Century;
		int Half_century;
		int total_runs;
		int total_wickets;
		
		Scanner input = new Scanner(System.in) ;
		
		for(int count=0; count<bowArr.length; count++ )
		{
			System.out.println("Enter Bowler" + (count+1) + "Informations:");
			
			System.out.println("Name:");
			String name = input.nextLine();
			
			System.out.println("Total Match:");
			int total_match = input.nextInt();
			
			System.out.println("Total ODI:");
			int total_ODI = input.nextInt();
			
			System.out.println("Total TEST:");
			int total_TEST = input.nextInt();
			
			System.out.println("Total T20:");
			int total_T20 = input.nextInt();
			
			System.out.println("Century:");
			int Century = input.nextInt();
			
			System.out.println("Half Century:");
			int Half_century = input.nextInt();
			
			System.out.println("Total Runs:");
			int total_runs = input.nextInt();
			
			System.out.println("Total Wickets:");
			int total_wickets = input.nextInt();
			
			input.nextLine();
		
			bowArr[count] = new Bowlers(name,total_match,total_ODI, total_TEST,total_T20 , Century, Half_century, total_runs, total_wickets);
			
		}
	
		Games1 g1 = new Games1();
		system.out.println("Average of Total ODI Matches:" + g1.averageOfODI(batArr));
		
	}
	
}
